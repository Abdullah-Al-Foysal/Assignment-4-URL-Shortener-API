<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>AAF URL Shortener</title>
  <style>
    /* Simple modern CSS */
    :root{
      --bg:#0f172a; --card:#0b1220; --accent1:#d693fd; --accent2:#a45af8; --muted:#9aa4b2;
    }
    body{font-family:Inter, system-ui, Arial; margin:0; padding:40px; background:linear-gradient(135deg,var(--bg),#091028); color:#fff;}
    .container{max-width:900px;margin:0 auto;}
    header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
    h1{margin:0;font-size:26px;}
    .card{background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); border-radius:12px; padding:20px; box-shadow: 0 8px 30px rgba(0,0,0,0.6);}
    .form-row{display:flex;gap:8px; margin-bottom:12px;}
    input, button, textarea{padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.06); background:transparent; color:#fff; outline:none;}
    input::placeholder{color:var(--muted)}
    button{cursor:pointer; background:linear-gradient(90deg,var(--accent1),var(--accent2)); border:none; font-weight:600;}
    .small{font-size:13px;color:var(--muted)}
    .urls{margin-top:16px;}
    .url-item{padding:12px;border-radius:10px;margin-bottom:8px;background:rgba(255,255,255,0.02);display:flex;justify-content:space-between;align-items:center;}
    .right{display:flex;gap:8px;align-items:center}
    .token-area{background:rgba(255,255,255,0.02); padding:10px;border-radius:8px; margin-top:8px; word-break:break-all;}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>ABDULLAH AL FOYSAL — URL Shortener</h1>
      <div class="small">Your Dream Our Inspiration</div>
    </header>

    <div class="card">
      <h3>1) Register / Login</h3>
      <div class="small">Use these forms to create account and get a token. Store token in Local Storage.</div>

      <div style="margin-top:12px;">
        <form id="registerForm" onsubmit="return false">
          <div class="form-row">
            <input id="reg_name" placeholder="Name" required />
            <input id="reg_email" placeholder="Email" required />
            <input id="reg_password" type="password" placeholder="Password" required />
            <input id="reg_password_confirm" type="password" placeholder="Password Confirm" required />
            <button onclick="register()">Register</button>
          </div>
        </form>

        <form id="loginForm" onsubmit="return false">
          <div class="form-row">
            <input id="login_email" placeholder="Email" />
            <input id="login_password" type="password" placeholder="Password" />
            <button onclick="login()">Login</button>
          </div>
        </form>

        <div class="small">Token (saved to localStorage):</div>
        <div id="tokenArea" class="token-area">No token yet.</div>
      </div>
    </div>

    <div class="card" style="margin-top:18px;">
      <h3>2) Shorten a URL</h3>
      <div class="form-row">
        <input id="original_url" placeholder="https://example.com/long/path" style="flex:1" />
        <button onclick="shorten()">Shorten</button>
      </div>
      <div class="small">After shortening you can view your list below.</div>

      <div class="urls" id="urlsList"></div>
    </div>
  </div>

  <script>
    const apiBase = location.origin + '/api';

    function setTokenUI(token) {
      if (!token) token = localStorage.getItem('api_token');
      const el = document.getElementById('tokenArea');
      el.textContent = token ? token : 'No token yet.';
    }

    async function register() {
      const data = {
        name: document.getElementById('reg_name').value,
        email: document.getElementById('reg_email').value,
        password: document.getElementById('reg_password').value,
        password_confirmation: document.getElementById('reg_password_confirm').value,
      };
      const res = await fetch(apiBase + '/register', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data)
      });
      const json = await res.json();
      if (res.ok) {
        localStorage.setItem('api_token', json.token);
        setTokenUI(json.token);
        alert('Registered and logged in.');
      } else {
        alert(JSON.stringify(json));
      }
    }

    async function login() {
      const data = {
        email: document.getElementById('login_email').value,
        password: document.getElementById('login_password').value
      };
      const res = await fetch(apiBase + '/login', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data)
      });
      const json = await res.json();
      if (res.ok) {
        localStorage.setItem('api_token', json.token);
        setTokenUI(json.token);
        alert('Logged in.');
      } else {
        alert(JSON.stringify(json));
      }
    }

    async function shorten() {
      const token = localStorage.getItem('api_token');
      if (!token) { alert('Please login first'); return; }
      const original_url = document.getElementById('original_url').value;
      const res = await fetch(apiBase + '/shorten', {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Authorization':'Bearer ' + token},
        body: JSON.stringify({ original_url })
      });
      const json = await res.json();
      if (res.ok) {
        alert('Shortened: ' + json.short_url);
        loadUrls();
      } else {
        alert(JSON.stringify(json));
      }
    }

    async function loadUrls() {
      const token = localStorage.getItem('api_token');
      if (!token) { document.getElementById('urlsList').innerHTML = '<div class="small">Login to see your URLs</div>'; return; }

      const res = await fetch(apiBase + '/urls', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      const json = await res.json();
      if (!res.ok) { document.getElementById('urlsList').innerText = JSON.stringify(json); return; }

      const list = json;
      const container = document.getElementById('urlsList');
      container.innerHTML = '';
      if (!list.length) { container.innerHTML = '<div class="small">No URLs yet.</div>'; return; }
      list.forEach(u => {
        const div = document.createElement('div');
        div.className = 'url-item';
        div.innerHTML = `<div>
            <div style="font-weight:600">${u.short_url}</div>
            <div class="small">${u.original_url}</div>
          </div>
          <div class="right">
            <div class="small">Visits: ${u.visits}</div>
            <a href="${u.short_url}" target="_blank"><button>Open</button></a>
          </div>`;
        container.appendChild(div);
      });
    }

    // boot
    setTokenUI();
    loadUrls();
  </script>
</body>
</html>
<?php /**PATH D:\Laravel Herd\laravel new\urlshortener\resources\views/welcome.blade.php ENDPATH**/ ?>