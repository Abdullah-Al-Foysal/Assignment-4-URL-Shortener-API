<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RedirectController;

Route::get('/', function () {
    return view('welcome'); // homepage Blade (see below)
});

// redirection route (catch all short codes at root level)
Route::get('/{short_code}', [RedirectController::class, 'go'])->where('short_code', '[A-Za-z0-9]{4,}');
