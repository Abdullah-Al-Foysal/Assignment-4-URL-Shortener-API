<?php
namespace App\Http\Controllers;

use App\Models\Url;
use Illuminate\Http\Request;

class RedirectController extends Controller
{
    // GET /{short_code}
    public function go($short_code)
    {
        $url = Url::where('short_code', $short_code)->first();

        if (! $url) {
            abort(404);
        }

        // optional: check expiration
        if ($url->expires_at && $url->expires_at->isPast()) {
            abort(410, 'This short link has expired.');
        }

        // increment visits
        $url->increment('visits');

        // redirect
        return redirect()->away($url->original_url);
    }
}
