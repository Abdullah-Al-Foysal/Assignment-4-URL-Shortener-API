<?php
namespace App\Http\Controllers;

use App\Models\Url;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class UrlController extends Controller
{
    // GET /api/urls
    public function index(Request $request)
    {
        $urls = $request->user()->urls()->orderBy('created_at', 'desc')->get();

        return response()->json($urls);
    }

    // POST /api/shorten
    public function shorten(Request $request)
    {
        $data = $request->validate([
            'original_url' => 'required|url|max:2048',
            'expires_at' => 'nullable|date|after:now',
        ]);

        // generate unique short code
        do {
            $code = Str::random(6); // 6 chars; adjust if you want shorter/longer
        } while (Url::where('short_code', $code)->exists());

        $base = $request->getSchemeAndHttpHost(); // will give host like http://localhost:8000
        $shortUrl = rtrim($base, '/') . '/' . $code;

        $url = Url::create([
            'user_id' => $request->user()->id,
            'original_url' => $data['original_url'],
            'short_code' => $code,
            'short_url' => $shortUrl,
            'expires_at' => $data['expires_at'] ?? null,
        ]);

        return response()->json($url, 201);
    }
}
